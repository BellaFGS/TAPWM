﻿namespace PTesteClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciaHorista = new System.Windows.Forms.Button();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.lab4 = new System.Windows.Forms.Label();
            this.lab3 = new System.Windows.Forms.Label();
            this.lab2 = new System.Windows.Forms.Label();
            this.lab1 = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.textHora = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textFaltas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstanciaHorista
            // 
            this.btnInstanciaHorista.Location = new System.Drawing.Point(142, 382);
            this.btnInstanciaHorista.Name = "btnInstanciaHorista";
            this.btnInstanciaHorista.Size = new System.Drawing.Size(201, 65);
            this.btnInstanciaHorista.TabIndex = 7;
            this.btnInstanciaHorista.Text = "Instanciar Horista";
            this.btnInstanciaHorista.UseVisualStyleBackColor = true;
            this.btnInstanciaHorista.Click += new System.EventHandler(this.btnInstanciaHorista_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(391, 107);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(384, 26);
            this.txtNome.TabIndex = 2;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(391, 151);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(117, 26);
            this.txtSalario.TabIndex = 3;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(391, 247);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(182, 26);
            this.txtData.TabIndex = 5;
            // 
            // lab4
            // 
            this.lab4.AutoSize = true;
            this.lab4.Location = new System.Drawing.Point(138, 253);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(195, 20);
            this.lab4.TabIndex = 14;
            this.lab4.Text = "Data Entrada na Empresa";
            // 
            // lab3
            // 
            this.lab3.AutoSize = true;
            this.lab3.Location = new System.Drawing.Point(138, 157);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(124, 20);
            this.lab3.TabIndex = 12;
            this.lab3.Text = "Salário por Hora";
            // 
            // lab2
            // 
            this.lab2.AutoSize = true;
            this.lab2.Location = new System.Drawing.Point(138, 113);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(51, 20);
            this.lab2.TabIndex = 10;
            this.lab2.Text = "Nome";
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Location = new System.Drawing.Point(138, 66);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(73, 20);
            this.lab1.TabIndex = 8;
            this.lab1.Text = "Matrícula";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(391, 60);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(117, 26);
            this.txtMatricula.TabIndex = 1;
            // 
            // textHora
            // 
            this.textHora.Location = new System.Drawing.Point(391, 202);
            this.textHora.Name = "textHora";
            this.textHora.Size = new System.Drawing.Size(117, 26);
            this.textHora.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(138, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "Número de horas";
            // 
            // textFaltas
            // 
            this.textFaltas.Location = new System.Drawing.Point(391, 296);
            this.textFaltas.Name = "textFaltas";
            this.textFaltas.Size = new System.Drawing.Size(182, 26);
            this.textFaltas.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(138, 302);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "Dias de Faltas";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 521);
            this.Controls.Add(this.textFaltas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnInstanciaHorista);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lab4);
            this.Controls.Add(this.lab3);
            this.Controls.Add(this.lab2);
            this.Controls.Add(this.lab1);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciaHorista;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox textHora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textFaltas;
        private System.Windows.Forms.Label label2;
    }
}