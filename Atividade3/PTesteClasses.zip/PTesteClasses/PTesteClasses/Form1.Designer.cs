﻿namespace PTesteClasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Horista = new System.Windows.Forms.Button();
            this.Mensalista = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Horista);
            this.groupBox1.Controls.Add(this.Mensalista);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1245, 574);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // Horista
            // 
            this.Horista.Location = new System.Drawing.Point(721, 193);
            this.Horista.Name = "Horista";
            this.Horista.Size = new System.Drawing.Size(240, 76);
            this.Horista.TabIndex = 1;
            this.Horista.Text = "Horista";
            this.Horista.UseVisualStyleBackColor = true;
            this.Horista.Click += new System.EventHandler(this.Horista_Click);
            // 
            // Mensalista
            // 
            this.Mensalista.Location = new System.Drawing.Point(222, 193);
            this.Mensalista.Name = "Mensalista";
            this.Mensalista.Size = new System.Drawing.Size(240, 76);
            this.Mensalista.TabIndex = 0;
            this.Mensalista.Text = "Mensalista";
            this.Mensalista.UseVisualStyleBackColor = true;
            this.Mensalista.Click += new System.EventHandler(this.Mensalista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 572);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Horista;
        private System.Windows.Forms.Button Mensalista;
    }
}

