﻿namespace PTesteClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lab1 = new System.Windows.Forms.Label();
            this.lab2 = new System.Windows.Forms.Label();
            this.lab3 = new System.Windows.Forms.Label();
            this.lab4 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnInstancia1 = new System.Windows.Forms.Button();
            this.btnInstancia2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(334, 47);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(103, 26);
            this.txtMatricula.TabIndex = 0;
            // 
            // lab1
            // 
            this.lab1.AutoSize = true;
            this.lab1.Location = new System.Drawing.Point(81, 53);
            this.lab1.Name = "lab1";
            this.lab1.Size = new System.Drawing.Size(73, 20);
            this.lab1.TabIndex = 1;
            this.lab1.Text = "Matrícula";
            // 
            // lab2
            // 
            this.lab2.AutoSize = true;
            this.lab2.Location = new System.Drawing.Point(81, 100);
            this.lab2.Name = "lab2";
            this.lab2.Size = new System.Drawing.Size(51, 20);
            this.lab2.TabIndex = 2;
            this.lab2.Text = "Nome";
            // 
            // lab3
            // 
            this.lab3.AutoSize = true;
            this.lab3.Location = new System.Drawing.Point(81, 144);
            this.lab3.Name = "lab3";
            this.lab3.Size = new System.Drawing.Size(113, 20);
            this.lab3.TabIndex = 3;
            this.lab3.Text = "Salário Mensal";
            // 
            // lab4
            // 
            this.lab4.AutoSize = true;
            this.lab4.Location = new System.Drawing.Point(81, 190);
            this.lab4.Name = "lab4";
            this.lab4.Size = new System.Drawing.Size(195, 20);
            this.lab4.TabIndex = 4;
            this.lab4.Text = "Data Entrada na Empresa";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(334, 184);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(182, 26);
            this.txtData.TabIndex = 3;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(334, 138);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(182, 26);
            this.txtSalario.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(334, 94);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(384, 26);
            this.txtNome.TabIndex = 1;
            // 
            // btnInstancia1
            // 
            this.btnInstancia1.Location = new System.Drawing.Point(183, 291);
            this.btnInstancia1.Name = "btnInstancia1";
            this.btnInstancia1.Size = new System.Drawing.Size(322, 87);
            this.btnInstancia1.TabIndex = 4;
            this.btnInstancia1.Text = "Instancia Mensalidade";
            this.btnInstancia1.UseVisualStyleBackColor = true;
            this.btnInstancia1.Click += new System.EventHandler(this.btnInstancia1_Click);
            // 
            // btnInstancia2
            // 
            this.btnInstancia2.Location = new System.Drawing.Point(692, 291);
            this.btnInstancia2.Name = "btnInstancia2";
            this.btnInstancia2.Size = new System.Drawing.Size(322, 87);
            this.btnInstancia2.TabIndex = 5;
            this.btnInstancia2.Text = "Instancia Mensalidade passando parâmetros";
            this.btnInstancia2.UseVisualStyleBackColor = true;
            this.btnInstancia2.Click += new System.EventHandler(this.btnInstancia2_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 450);
            this.Controls.Add(this.btnInstancia2);
            this.Controls.Add(this.btnInstancia1);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lab4);
            this.Controls.Add(this.lab3);
            this.Controls.Add(this.lab2);
            this.Controls.Add(this.lab1);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lab1;
        private System.Windows.Forms.Label lab2;
        private System.Windows.Forms.Label lab3;
        private System.Windows.Forms.Label lab4;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnInstancia1;
        private System.Windows.Forms.Button btnInstancia2;
    }
}